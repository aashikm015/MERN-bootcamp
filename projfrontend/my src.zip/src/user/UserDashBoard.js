import React from "react";
import Base from "../core/Base";

const UserDashBoard = () => {
  return (
    <Base title="UserDashBoard page">
      <h1>THis is UserDashBoard page</h1>
    </Base>
  );
};

export default UserDashBoard;
